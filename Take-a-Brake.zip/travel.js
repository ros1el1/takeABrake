var submit = $(".submitB");
submit.on("click", function(event) {
    event.preventDefault();
    ThankYou();
  });
function ThankYou() {
  alert("Thank you for your suggestion, we will try and add it to our list!");
}