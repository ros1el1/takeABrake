var button = $(".submitButton");
button.on("click", function(event) {
    event.preventDefault();
    thankYou();
  });
function thankYou() {
  alert("Thank you for your suggestion!");
}