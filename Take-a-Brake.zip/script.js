// var happyButton = $(".happy");
// var happyText = $(".outputTextHappy");
// // var happyImage = $(".happyface")

// happyButton.on("click", happyMessage);

// function happyMessage(event) {
//   event.preventDefault();
//   happyText.text("Hello, I'm happy!");
//   var happyImage = happyButton.find(".happyface");

//   happyImage.remove(); // Remove the image
//   happyButton.text(happyText); // Set the text inside the button
// }
